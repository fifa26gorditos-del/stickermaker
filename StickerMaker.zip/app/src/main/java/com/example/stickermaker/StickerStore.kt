package com.example.stickermaker

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import java.io.ByteArrayOutputStream
import java.io.File

@Suppress("DEPRECATION")
object StickerStore {
    const val PACK_ID = "mis_stickers"
    const val NAME = "Mis stickers"
    private val FMT = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP

    fun dir(c: Context) = File(c.filesDir, "pack").apply { mkdirs() }
    fun files(c: Context): List<File> =
        dir(c).listFiles { f -> f.name.startsWith("sticker_") }?.sortedBy { it.lastModified() } ?: emptyList()
    fun version(c: Context) = (dir(c).listFiles()?.maxOfOrNull { it.lastModified() } ?: 0L).toString()

    fun load(c: Context, uri: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        o.inSampleSize = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1500)
        o.inJustDecodeBounds = false
        return c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    }

    /** Guarda el sticker (WebP 512x512, <100 KB). Devuelve el peso en KB. */
    fun add(c: Context, bmp: Bitmap): Int {
        var q = 95
        val out = ByteArrayOutputStream()
        do { out.reset(); bmp.compress(FMT, q, out); q -= 10 } while (out.size() > 100_000 && q > 5)
        val d = dir(c)
        File(d, "sticker_${System.currentTimeMillis()}.webp").writeBytes(out.toByteArray())
        val tray = Bitmap.createScaledBitmap(bmp, 96, 96, true)
        File(d, "tray.png").outputStream().use { tray.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return out.size() / 1024
    }

    fun intent(c: Context) = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK").apply {
        putExtra("sticker_pack_id", PACK_ID)
        putExtra("sticker_pack_authority", c.packageName + ".stickers")
        putExtra("sticker_pack_name", NAME)
    }
}
