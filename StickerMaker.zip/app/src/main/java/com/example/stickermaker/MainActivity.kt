package com.example.stickermaker

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }
}

fun render(src: Bitmap, zoom: Float, rot: Float, text: String, res: Int): Bitmap {
    val base = Bitmap.createBitmap(res, res, Bitmap.Config.ARGB_8888)
    val c = Canvas(base)
    val s = minOf(res / src.width.toFloat(), res / src.height.toFloat()) * zoom
    val m = Matrix().apply {
        postTranslate(-src.width / 2f, -src.height / 2f); postScale(s, s)
        postRotate(rot); postTranslate(res / 2f, res / 2f)
    }
    c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
    if (text.isNotBlank()) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER; textSize = res * 0.14f; isFakeBoldText = true
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = res * 0.02f; p.color = android.graphics.Color.BLACK
        c.drawText(text, res / 2f, res * 0.92f, p)
        p.style = Paint.Style.FILL; p.color = android.graphics.Color.WHITE
        c.drawText(text, res / 2f, res * 0.92f, p)
    }
    return Bitmap.createScaledBitmap(base, 512, 512, true)
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    var src by remember { mutableStateOf<Bitmap?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var rot by remember { mutableFloatStateOf(0f) }
    var text by remember { mutableStateOf("") }
    var res by remember { mutableIntStateOf(512) }
    var count by remember { mutableIntStateOf(StickerStore.files(ctx).size) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { src = StickerStore.load(ctx, it) }
    }
    val wa = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    val preview = src?.let { render(it, zoom, rot, text, res) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(onClick = { pick.launch("image/*") }) { Text("Elegir imagen") }
        preview?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().aspectRatio(1f)) }
        Text("Zoom")
        Slider(zoom, { zoom = it }, valueRange = 0.3f..3f)
        Text("Rotación")
        Slider(rot, { rot = it }, valueRange = 0f..360f)
        OutlinedTextField(text, { text = it }, label = { Text("Texto (opcional)") }, modifier = Modifier.fillMaxWidth())
        Text("Resolución")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(256, 384, 512).forEach { r -> FilterChip(res == r, { res = r }, { Text("$r px") }) }
        }
        Button(enabled = preview != null && count < 30, onClick = {
            val kb = StickerStore.add(ctx, preview!!)
            count = StickerStore.files(ctx).size
            Toast.makeText(ctx, "Sticker guardado ($kb KB)", Toast.LENGTH_SHORT).show()
        }) { Text("Guardar sticker ($count/30)") }
        Button(enabled = count >= 3, onClick = {
            try { wa.launch(StickerStore.intent(ctx)) }
            catch (e: Exception) { Toast.makeText(ctx, "No se pudo abrir WhatsApp: ${e.message}", Toast.LENGTH_LONG).show() }
        }) { Text("Agregar pack a WhatsApp") }
        if (count < 3) Text("Guarda al menos 3 stickers para agregar el pack.")
    }
}
