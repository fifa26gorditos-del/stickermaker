package com.example.stickermaker

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File

class StickerProvider : ContentProvider() {
    private val m = UriMatcher(UriMatcher.NO_MATCH)

    override fun onCreate(): Boolean {
        val a = context!!.packageName + ".stickers"
        m.addURI(a, "metadata", 1); m.addURI(a, "metadata/*", 1)
        m.addURI(a, "stickers/*", 2); m.addURI(a, "stickers_asset/*/*", 3)
        return true
    }

    override fun query(uri: Uri, p: Array<String>?, s: String?, sa: Array<String>?, o: String?): Cursor? {
        val c = context!!
        return when (m.match(uri)) {
            1 -> MatrixCursor(arrayOf(
                "sticker_pack_identifier", "sticker_pack_name", "sticker_pack_publisher", "sticker_pack_icon",
                "android_play_store_link", "ios_app_download_link", "sticker_pack_publisher_email",
                "sticker_pack_publisher_website", "sticker_pack_privacy_policy_website",
                "sticker_pack_license_agreement_website", "image_data_version",
                "whatsapp_will_not_cache_stickers", "animated_sticker_pack"
            )).apply {
                addRow(arrayOf(StickerStore.PACK_ID, StickerStore.NAME, "Yo", "tray.png",
                    "", "", "", "", "", "", StickerStore.version(c), 0, 0))
            }
            2 -> MatrixCursor(arrayOf("sticker_file_name", "sticker_emoji", "sticker_accessibility_text")).apply {
                StickerStore.files(c).forEach { addRow(arrayOf(it.name, "😀", "Sticker")) }
            }
            else -> null
        }
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        if (m.match(uri) != 3) return null
        val f = File(StickerStore.dir(context!!), File(uri.lastPathSegment!!).name)
        return AssetFileDescriptor(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY), 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    override fun getType(uri: Uri): String? = when (m.match(uri)) {
        1 -> "vnd.android.cursor.dir/vnd.${context!!.packageName}.stickers.metadata"
        2 -> "vnd.android.cursor.dir/vnd.${context!!.packageName}.stickers"
        3 -> if (uri.lastPathSegment!!.endsWith(".png")) "image/png" else "image/webp"
        else -> null
    }

    override fun insert(uri: Uri, v: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<String>?) = 0
}
