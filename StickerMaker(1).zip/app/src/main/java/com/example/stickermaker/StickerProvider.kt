package com.example.stickermaker

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File

class StickerProvider : ContentProvider() {
    private val m = UriMatcher(UriMatcher.NO_MATCH)

    override fun onCreate(): Boolean {
        val a = context!!.packageName + ".stickers"
        m.addURI(a, "metadata", 1); m.addURI(a, "metadata/*", 2)
        m.addURI(a, "stickers/*", 3); m.addURI(a, "stickers_asset/*/*", 4)
        return true
    }

    override fun query(uri: Uri, p: Array<String>?, s: String?, sa: Array<String>?, o: String?): Cursor? {
        val c = context!!
        return when (m.match(uri)) {
            1, 2 -> {
                val id = if (m.match(uri) == 2) uri.lastPathSegment else null
                MatrixCursor(arrayOf(
                    "sticker_pack_identifier", "sticker_pack_name", "sticker_pack_publisher", "sticker_pack_icon",
                    "android_play_store_link", "ios_app_download_link", "sticker_pack_publisher_email",
                    "sticker_pack_publisher_website", "sticker_pack_privacy_policy_website",
                    "sticker_pack_license_agreement_website", "image_data_version",
                    "whatsapp_will_not_cache_stickers", "animated_sticker_pack"
                )).apply {
                    StickerStore.PACKS.filter { (id == null || it.id == id) && StickerStore.files(c, it).isNotEmpty() }
                        .forEach { k ->
                            addRow(arrayOf(k.id, k.name, "Yo", "tray.png", "", "", "", "", "", "",
                                StickerStore.version(c, k), 0, if (k.animated) 1 else 0))
                        }
                }
            }
            3 -> MatrixCursor(arrayOf("sticker_file_name", "sticker_emoji", "sticker_accessibility_text")).apply {
                StickerStore.PACKS.firstOrNull { it.id == uri.lastPathSegment }?.let { k ->
                    StickerStore.files(c, k).forEach { addRow(arrayOf(it.name, "😀", "Sticker")) }
                }
            }
            else -> null
        }
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        if (m.match(uri) != 4) return null
        val seg = uri.pathSegments
        val k = StickerStore.PACKS.firstOrNull { it.id == seg[1] } ?: return null
        val f = File(StickerStore.dir(context!!, k), File(seg[2]).name)
        return AssetFileDescriptor(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY), 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    override fun getType(uri: Uri): String? = when (m.match(uri)) {
        1, 2 -> "vnd.android.cursor.dir/vnd.${context!!.packageName}.stickers.metadata"
        3 -> "vnd.android.cursor.dir/vnd.${context!!.packageName}.stickers"
        4 -> if (uri.lastPathSegment!!.endsWith(".png")) "image/png" else "image/webp"
        else -> null
    }

    override fun insert(uri: Uri, v: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<String>?) = 0
}
