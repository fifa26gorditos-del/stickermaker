package com.example.stickermaker

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Movie
import android.net.Uri
import android.os.Build
import java.io.ByteArrayOutputStream
import java.io.File

class Source(val frames: List<Bitmap>, val stepMs: Int)
class Pack(val id: String, val name: String, val animated: Boolean)

@Suppress("DEPRECATION")
object StickerStore {
    val PACKS = listOf(
        Pack("mis_stickers", "Mis stickers", false),
        Pack("mis_stickers_animados", "Mis stickers animados", true)
    )
    private val FMT = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP

    fun dir(c: Context, p: Pack) = File(c.filesDir, p.id).apply { mkdirs() }
    fun files(c: Context, p: Pack): List<File> =
        dir(c, p).listFiles { f -> f.name.startsWith("sticker_") }?.sortedBy { it.name } ?: emptyList()
    fun version(c: Context, p: Pack): String {
        val fs = dir(c, p).listFiles() ?: return "0"
        return "${fs.maxOfOrNull { it.lastModified() } ?: 0L}-${fs.size}"
    }

    fun load(c: Context, uri: Uri): Source? {
        if (c.contentResolver.getType(uri) == "image/gif") loadGif(c, uri)?.let { return it }
        return loadBitmap(c, uri)?.let { Source(listOf(it), 0) }
    }

    private fun loadBitmap(c: Context, uri: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        o.inSampleSize = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1500)
        o.inJustDecodeBounds = false
        return c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    }

    private fun loadGif(c: Context, uri: Uri): Source? {
        val bytes = c.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val mv = Movie.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val dur = mv.duration()
        if (dur <= 0 || mv.width() <= 0 || mv.height() <= 0) return null
        val total = minOf(dur, 10_000)
        val step = maxOf(100, total / 60)
        val sc = minOf(1f, 512f / maxOf(mv.width(), mv.height()))
        val w = maxOf(1, (mv.width() * sc).toInt()); val h = maxOf(1, (mv.height() * sc).toInt())
        val out = ArrayList<Bitmap>()
        var t = 0
        while (t < total) {
            mv.setTime(t)
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b); cv.scale(sc, sc); mv.draw(cv, 0f, 0f)
            out.add(b); t += step
        }
        return Source(out, step)
    }

    private fun encodeStatic(b: Bitmap): ByteArray {
        var q = 95
        val o = ByteArrayOutputStream()
        do { o.reset(); b.compress(FMT, q, o); q -= 10 } while (o.size() > 100_000 && q > 5)
        return o.toByteArray()
    }

    private fun encodeAnim(s: Source, make: (Bitmap) -> Bitmap): ByteArray? {
        var frames = s.frames; var dur = s.stepMs
        while (true) {
            for (q in intArrayOf(60, 40, 20)) {
                val parts = frames.map { f -> ByteArrayOutputStream().also { make(f).compress(FMT, q, it) }.toByteArray() }
                val data = WebpAnim.build(parts, dur, 512, 512)
                if (data.size <= 500_000) return data
            }
            if (frames.size <= 8) return null
            frames = frames.filterIndexed { i, _ -> i % 2 == 0 }; dur *= 2
        }
    }

    /** Guarda el sticker. Devuelve KB, o -1 si el GIF no logra bajar de 500 KB. */
    fun add(c: Context, s: Source, make: (Bitmap) -> Bitmap): Int {
        val first = make(s.frames[0])
        val animated = s.frames.size > 1
        val p = PACKS.first { it.animated == animated }
        val data = (if (animated) encodeAnim(s, make) else encodeStatic(first)) ?: return -1
        val d = dir(c, p)
        File(d, "sticker_${System.currentTimeMillis()}.webp").writeBytes(data)
        val tray = Bitmap.createScaledBitmap(first, 96, 96, true)
        File(d, "tray.png").outputStream().use { tray.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return data.size / 1024
    }

    fun intent(c: Context, p: Pack) = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK").apply {
        putExtra("sticker_pack_id", p.id)
        putExtra("sticker_pack_authority", c.packageName + ".stickers")
        putExtra("sticker_pack_name", p.name)
    }
}

/** Arma un WebP animado juntando fotogramas WebP sueltos (contenedor RIFF: VP8X + ANIM + ANMF). */
object WebpAnim {
    private fun le(v: Int, n: Int) = ByteArray(n) { ((v shr (8 * it)) and 0xFF).toByte() }
    private fun chunk(tag: String, data: ByteArray) =
        tag.toByteArray() + le(data.size, 4) + data + ByteArray(data.size % 2)

    private fun frameChunks(w: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        var p = 12
        while (p + 8 <= w.size) {
            val tag = String(w, p, 4)
            val sz = (w[p + 4].toInt() and 255) or ((w[p + 5].toInt() and 255) shl 8) or
                ((w[p + 6].toInt() and 255) shl 16) or ((w[p + 7].toInt() and 255) shl 24)
            if (tag == "ALPH" || tag == "VP8 " || tag == "VP8L") {
                o.write(w, p, 8 + sz); if (sz % 2 == 1) o.write(0)
            }
            p += 8 + sz + (sz and 1)
        }
        return o.toByteArray()
    }

    fun build(frames: List<ByteArray>, durMs: Int, w: Int, h: Int): ByteArray {
        val body = ByteArrayOutputStream()
        body.write("WEBP".toByteArray())
        body.write(chunk("VP8X", byteArrayOf(0x12, 0, 0, 0) + le(w - 1, 3) + le(h - 1, 3)))
        body.write(chunk("ANIM", ByteArray(4) + le(0, 2)))
        for (f in frames) {
            val head = le(0, 3) + le(0, 3) + le(w - 1, 3) + le(h - 1, 3) + le(durMs, 3) + byteArrayOf(3)
            body.write(chunk("ANMF", head + frameChunks(f)))
        }
        val b = body.toByteArray()
        return "RIFF".toByteArray() + le(b.size, 4) + b
    }
}
