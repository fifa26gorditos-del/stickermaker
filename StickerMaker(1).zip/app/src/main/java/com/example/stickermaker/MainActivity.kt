package com.example.stickermaker

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }
}

fun render(src: Bitmap, zoom: Float, rot: Float, ox: Float, oy: Float, text: String, res: Int): Bitmap {
    val base = Bitmap.createBitmap(res, res, Bitmap.Config.ARGB_8888)
    val c = Canvas(base)
    val s = minOf(res / src.width.toFloat(), res / src.height.toFloat()) * zoom
    val m = Matrix().apply {
        postTranslate(-src.width / 2f, -src.height / 2f); postScale(s, s)
        postRotate(rot); postTranslate(res / 2f + ox * res, res / 2f + oy * res)
    }
    c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
    if (text.isNotBlank()) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER; textSize = res * 0.14f; isFakeBoldText = true
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = res * 0.02f; p.color = android.graphics.Color.BLACK
        c.drawText(text, res / 2f, res * 0.92f, p)
        p.style = Paint.Style.FILL; p.color = android.graphics.Color.WHITE
        c.drawText(text, res / 2f, res * 0.92f, p)
    }
    return Bitmap.createScaledBitmap(base, 512, 512, true)
}

@Composable
fun Screen() {
    var tab by remember { mutableIntStateOf(0) }
    var rev by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Crear") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Mis stickers") })
        }
        if (tab == 0) Create(rev) { rev++ } else Library(rev) { rev++ }
    }
}

@Composable
fun Create(rev: Int, onChange: () -> Unit) {
    val ctx = LocalContext.current
    var src by remember { mutableStateOf<Source?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var rot by remember { mutableFloatStateOf(0f) }
    var ox by remember { mutableFloatStateOf(0f) }
    var oy by remember { mutableFloatStateOf(0f) }
    var text by remember { mutableStateOf("") }
    var res by remember { mutableIntStateOf(512) }
    var crop by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var boxW by remember { mutableIntStateOf(1) }
    val wa = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            src = StickerStore.load(ctx, it)
            zoom = 1f; rot = 0f; ox = 0f; oy = 0f; crop = false
            if (src == null) Toast.makeText(ctx, "No se pudo abrir la imagen", Toast.LENGTH_SHORT).show()
        }
    }
    val cur = src
    val preview = cur?.let { render(it.frames[0], zoom, rot, ox, oy, text, res) }
    val n = StickerStore.PACKS.map { StickerStore.files(ctx, it).size }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(onClick = { pick.launch("image/*") }) { Text("Elegir imagen o GIF") }
        if (cur != null && preview != null) {
            Box(
                Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFFE0E0E0))
                    .then(if (crop) Modifier.border(3.dp, Color.Red) else Modifier)
                    .onSizeChanged { boxW = maxOf(1, it.width) }
                    .pointerInput(crop) {
                        if (crop) detectTransformGestures { _, pan, z, r ->
                            ox += pan.x / boxW; oy += pan.y / boxW
                            zoom = (zoom * z).coerceIn(0.2f, 5f)
                            rot = ((rot + r) % 360f + 360f) % 360f
                        }
                    }
            ) { Image(preview.asImageBitmap(), null, Modifier.fillMaxSize()) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { crop = !crop }) { Text(if (crop) "Listo" else "✂ Recortar") }
                OutlinedButton(onClick = { zoom = 1f; rot = 0f; ox = 0f; oy = 0f }) { Text("Reiniciar") }
            }
            if (crop) Text("Arrastra con un dedo para mover; pellizca para acercar o girar. Lo que queda dentro del cuadro es el sticker.")
            if (cur.frames.size > 1) Text("GIF animado: ${cur.frames.size} fotogramas")
        }
        Text("Zoom")
        Slider(zoom.coerceIn(0.3f, 3f), { zoom = it }, valueRange = 0.3f..3f)
        Text("Rotación")
        Slider(rot.coerceIn(0f, 360f), { rot = it }, valueRange = 0f..360f)
        OutlinedTextField(text, { text = it }, label = { Text("Texto (opcional)") }, modifier = Modifier.fillMaxWidth())
        Text("Resolución")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(256, 384, 512).forEach { r -> FilterChip(res == r, { res = r }, { Text("$r px") }) }
        }
        Button(enabled = cur != null && !busy, onClick = {
            val s = cur!!
            val z = zoom; val r = rot; val x = ox; val y = oy; val t = text; val rs = res
            busy = true
            Thread {
                val kb = try { StickerStore.add(ctx, s) { b -> render(b, z, r, x, y, t, rs) } } catch (e: Throwable) { -2 }
                Handler(Looper.getMainLooper()).post {
                    busy = false; onChange()
                    val msg = when {
                        kb >= 0 -> "Sticker guardado ($kb KB)"
                        kb == -1 -> "No se pudo bajar el GIF de 500 KB. Prueba con una resolución menor."
                        else -> "Error al guardar el sticker"
                    }
                    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                }
            }.start()
        }) { Text(if (busy) "Procesando..." else "Guardar sticker") }
        Text("Estáticos: ${n[0]}/30 · Animados: ${n[1]}/30")
        StickerStore.PACKS.forEachIndexed { i, p ->
            Button(enabled = n[i] >= 3, onClick = {
                try { wa.launch(StickerStore.intent(ctx, p)) }
                catch (e: Exception) { Toast.makeText(ctx, "No se pudo abrir WhatsApp", Toast.LENGTH_LONG).show() }
            }) { Text("Agregar «${p.name}» a WhatsApp") }
        }
        Text("Cada pack necesita al menos 3 stickers. Los GIFs van a su propio pack porque WhatsApp no permite mezclar animados con estáticos.")
    }
}

@Composable
fun Library(rev: Int, onChange: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StickerStore.PACKS.forEach { p ->
            val fs = StickerStore.files(ctx, p)
            Text("${p.name} (${fs.size}/30)", style = MaterialTheme.typography.titleMedium)
            if (fs.isEmpty()) Text("Todavía no hay stickers.")
            fs.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { f ->
                        val bmp = remember(f.path) {
                            try { BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 2 }) } catch (e: Throwable) { null }
                        }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFFE0E0E0))) {
                                if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize())
                            }
                            TextButton(onClick = { f.delete(); onChange() }) { Text("Eliminar") }
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            HorizontalDivider()
        }
        Text("Si eliminas o agregas stickers, vuelve a tocar «Agregar a WhatsApp» en la pestaña Crear para actualizar el pack.")
    }
}
